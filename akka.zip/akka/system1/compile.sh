#!/bin/sh
javac -classpath ../lib/*:. *.java
