#!/bin/sh
java -classpath ../lib/*:. Main

