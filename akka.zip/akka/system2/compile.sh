#!/bin/sh
javac -classpath ../lib/*:../system1/:. *.java
