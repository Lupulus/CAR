#!/bin/sh
java -classpath ./:../lib/*:../system1/ Main

